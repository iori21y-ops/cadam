# ═══════════════════════════════════════════
# 카담 업데이트 규칙 (기존 .cursorrules 교체)
# ═══════════════════════════════════════════

## 프로젝트 개요
**카담(CADAM)** — 자동차 금융상품 추천 + 차종 추천 + 장기렌트 견적 서비스.
Apple 디자인 스타일의 미니멀한 UI로 한국 30~40대 자영업자/직장인 대상.

## 기술 스택 (변경 없음)
- Next.js 16 (App Router) + TypeScript
- Tailwind CSS 4 (`@theme inline` in globals.css)
- Supabase (PostgreSQL + Auth + RLS)
- Zustand + persist middleware
- Framer Motion
- Vercel 배포
- Upstash Redis (Rate Limiting)
- Anthropic Claude API (서버사이드만)

## ★ 디자인 시스템 (Apple 스타일 — 전체 적용)

### 색상 (globals.css @theme inline)
```
--color-primary: #007AFF     (Apple Blue — 모든 액센트)
--color-success: #34C759     (Apple Green)
--color-warning: #FF9500     (Apple Orange)
--color-danger: #FF3B30      (Apple Red)
--color-kakao: #FEE500
--color-text: #1D1D1F        (제목, 강조)
--color-text-sub: #86868B    (본문)
--color-text-muted: #AEAEB2  (보조)
--color-surface: #FFFFFF     (카드)
--color-surface-secondary: #F5F5F7 (배경)
--color-border: rgba(0,0,0,0.06)
--color-finance: #007AFF
--color-vehicle: #5856D6
--color-option: #E04DBF
--color-calculator: #FF9500
--color-rent: #34C759
```

### 폰트
- Pretendard Variable (기존 유지)
- 제목: text-2xl~4xl font-bold tracking-tight
- 본문: text-sm~base text-text-sub

### 핵심 패턴
- **배경**: bg-surface-secondary (#F5F5F7), NOT bg-white
- **카드**: bg-surface rounded-2xl shadow-sm (border 사용하지 않음)
- **네비게이션**: glass 효과 (backdrop-filter blur + 반투명 배경)
- **버튼**: rounded-2xl, primary 배경, shadow-lg shadow-primary/20
- **호버**: hover:scale-[1.01] hover:shadow-md transition-all
- **선택 상태**: bg-primary text-white + 체크 아이콘
- **텍스트 계층**: text-text (제목) → text-text-sub (본문) → text-text-muted (보조)
- **그래디언트**: 사용하지 않음. 단색 위주.

### 금지
- border-2 border-gray-200 카드 패턴 사용 금지
- 진한 그래디언트 히어로 배경 사용 금지
- bg-white를 body/main 배경으로 사용 금지 (bg-surface-secondary 사용)
- 기존 네이비(#1B3A5C) 색상 사용 금지

## 코딩 규칙 (기존 유지 + 추가)

### 파일/폴더
- 기존 규칙 유지
- 진단 모듈: `src/components/diagnosis/` 하위에 격리
- 진단 데이터: `src/data/diagnosis-*.ts` (접두사로 구분)
- 진단 타입: `src/types/diagnosis.ts` (기존 타입과 분리)

### TypeScript
- any 금지, strict mode, interface 우선
- Next.js 16 환경: params/searchParams는 Promise로 처리

### Tailwind CSS
- 인라인 style 금지
- 모든 색상은 디자인 시스템 변수 사용
- 모바일 퍼스트

### 데이터
- 차량: `src/constants/vehicles.ts`의 VEHICLE_LIST (45종)
- 진단 질문: `src/data/diagnosis-*.ts`
- 가격: Supabase price_ranges (프론트 계산 금지)
- 진단 설정: Supabase diagnosis_config

### 금지 사항
- CSS-in-JS, CSS 모듈 사용 금지
- pages/ 디렉토리 사용 금지
- 프론트엔드에서 leadScore 계산 금지
- localStorage 직접 접근 금지
- console.log 프로덕션 코드에 남기지 말 것
- Claude API 키를 프론트엔드에 절대 노출 금지

## 주요 참고 파일
- 전체 PRD: @docs/PRD.md
- 진단 PRD: @docs/DIAGNOSIS-PRD.md
- 디자인 가이드: @docs/DESIGN-MIGRATION.md
- 동작 레퍼런스: @docs/prototype-reference.jsx
- 차량 데이터: @src/constants/vehicles.ts
- 견적 스토어: @src/store/quoteStore.ts
- 진단 타입: @src/types/diagnosis.ts
- 진단 엔진: @src/lib/flow-engine.ts
